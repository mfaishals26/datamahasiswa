import java.util.Scanner;

public class Mahasiswa23E {

    public static void main(String[] args) {
        Mahasiswa mhs = new Mahasiswa();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n=== MENU MAHASISWA ===");
            System.out.println("1. Lihat Data Mahasiswa");
            System.out.println("2. Tambah Mahasiswa Baru");
            System.out.println("3. Cari Mahasiswa Berdasarkan NIM");
            System.out.println("4. Update Data Mahasiswa");
            System.out.println("5. Hapus Data Mahasiswa");
            System.out.println("0. Keluar");
            System.out.print("Pilih menu: ");
            String pilihan = scanner.nextLine();

            switch (pilihan) {
                case "1":
                    mhs.readMahasiswa();
                    break;

                case "2":
                    System.out.print("Masukkan NIM: ");
                    String nim = scanner.nextLine();
                    if (mhs.findMahasiswaByNim(nim)) {
                        System.out.println("NIM sudah dipakai!");
                    } else {
                        System.out.print("Masukkan Nama: ");
                        String nama = scanner.nextLine();
                        System.out.print("Masukkan Alamat: ");
                        String alamat = scanner.nextLine();
                        System.out.print("Masukkan Gender (L/P): ");
                        String gender = scanner.nextLine();
                        mhs.insertMahasiswa(nim, nama, alamat, gender);
                    }
                    break;

                case "3":
                    System.out.print("Masukkan NIM yang dicari: ");
                    String cariNim = scanner.nextLine();
                    boolean ditemukan = mhs.findMahasiswaByNim(cariNim);
                    if (ditemukan) {
                        System.out.println("Mahasiswa dengan NIM " + cariNim + " ditemukan.");
                    } else {
                        System.out.println("Mahasiswa tidak ditemukan.");
                    }
                    break;

                case "4":
                    System.out.print("Masukkan NIM : ");
                    String nimUpdate = scanner.nextLine();
                    if (mhs.findMahasiswaByNim(nimUpdate)) {
                        System.out.print("Masukkan Nama baru: ");
                        String namaBaru = scanner.nextLine();
                        System.out.print("Masukkan Alamat baru: ");
                        String alamatBaru = scanner.nextLine();
                        System.out.print("Masukkan Gender baru (L/P): ");
                        String genderBaru = scanner.nextLine();

                        mhs.updateMahasiswa(nimUpdate, namaBaru, alamatBaru, genderBaru);
                        System.out.println("Data mahasiswa berhasil diupdate.");
                    } else {
                        System.out.println("Mahasiswa dengan NIM tersebut tidak ditemukan.");
                    }
                    break;

                case "5":
                    System.out.print("Masukkan NIM mahasiswa yang ingin dihapus: ");
                    String nimHapus = scanner.nextLine();
                    if (mhs.findMahasiswaByNim(nimHapus)) {
                        mhs.deleteMahasiswa(nimHapus);
                    } else {
                        System.out.println("Mahasiswa dengan NIM tersebut tidak ditemukan.");
                    }
                    break;

                case "0":
                    System.out.println("Program selesai.");
                    return;

                default:
                    System.out.println("Pilihan tidak valid.");
            }
        }
    }
}
